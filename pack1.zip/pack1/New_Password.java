package pack1;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class New_Password 
{
	
	public New_Password(String User_Id, Connection con) throws Exception 
	{
		BufferedReader s = new BufferedReader(new InputStreamReader(System.in));
		// TODO Auto-generated constructor stub
		for(int count = 0;count<3;count++){
			
		//Scanner s = new Scanner(System.in);
		/*System.out.println("Enter the new password: ");
		String password = s.readLine();
		System.out.println("Retype the password: ");
		String new_pswd = s.readLine();*/
		//String dbPsw = EncryptDecrypt.encrypt(new_pswd);
		Statement st = con.createStatement();
		int flag=0;
		int b = new PassSpec().Spec();
		if(b==1)
		{
			PasswordCheck PC = new PasswordCheck();
			int ps = PC.CheckPsw(User_Id,PassSpec.Rpassword, con);
						/**
						 * SUCCESS LOGIN LOOP
						 */
		//	System.out.println("this is ps"+ps);
			if(ps==-1){
				System.out.println("You can not choose last 10 passwords. Kindly provide a new password");
				System.out.println("Enter the Password Again(Tries left=)"+ (2 - count));
				//new_pswd = s.readLine();
			}
			else{
				//System.out.println("Success");
				new AbruptCheck(User_Id);
				String update_isloggedin = "Update Account set is_logged_in = 1 where User_Id='"+ FetchUserId.User_Id + "'";
				st.executeQuery(update_isloggedin);
				String dbPsw = new EncryptDecrypt().encrypt(PassSpec.Rpassword);
				String update_password = "Update User_Details set password ='"+dbPsw+"' where user_name='"+ User_Id + "'";
				st.executeUpdate(update_password);
				flag=1;
				SimpleMailDemo obj = new SimpleMailDemo(FetchData.Email,"Password Changed","Hi! Your password has been changed. If you didn't changed it please contact us: shahbhumika.93@gmail.com");
				break;
			}
		}
		else
		{
			System.out.println("Enter the Password Again(Tries left=)"+ (2 - count));
			//new_pswd = s.readLine();
		}
		if (count == 2 && flag == 0) 
		{
					/**
					 * SENDING MAIL AND BLOCKING THE ACCOUNT
					 */
					//System.out.println(FetchData.Email);
			SimpleMailDemo obj = new SimpleMailDemo(FetchData.Email,"Account Blocked","Someone hacked into your account");
			String update_inactive = "Update Account set is_active= 0, pass_status=2 where User_Id='"+ FetchUserId.User_Id + "'";
			st.executeQuery(update_inactive);
			new Login().logging();
		}
		}
	}
}
