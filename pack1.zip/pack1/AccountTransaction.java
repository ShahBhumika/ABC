package pack1;

public class AccountTransaction 
{
	String firstName;
	String lastName;
	String HouseNo;
	String PlotNo;
	String Street;
	String City;
	String State;
	String phNo;
	int accNo;
	String transactionType;
	String amount;
	int accBalance;
	String transactionDate;
	public AccountTransaction(String firstName, String lastName,
			String HouseNo,String PlotNo, String Street, String City, String State, String phNo, int accNo,
			String transactionType, String amount, int accBalance,String transactionDate)
	{
		
		this.firstName = firstName;
		this.lastName = lastName;
		this.HouseNo = HouseNo;
		this.PlotNo = PlotNo;
		this.Street = Street;
		this.City = City;
		this.State = State;
		this.phNo = phNo;
		this.accNo = accNo;
		this.transactionType = transactionType;
		this.amount = amount;
		this.accBalance = accBalance;
		this.transactionDate=transactionDate;
	}
}
