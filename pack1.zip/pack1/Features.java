package pack1;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.Scanner;
public class Features
{	static LogThread lt;
	public static BufferedReader br;
	//public static InputStreamReader ins;
	public Features(){
		 //new FetchData();
		lt = new LogThread();
		lt.start();
	}
	
	public static void showPage() throws SQLException, Exception{

		//DbConnection con = DbConnection.getInstance();
		//Connection conn = con.getConnection();
		int flag = 0;
		String input;
		while(true){
			
				System.out.println("1. Account Summary");
				System.out.println("2. Make fund transfer");
				System.out.println("3. View Passbook");
				System.out.println("4. Change Password");
				System.out.println("5. Log Out");	
				System.out.println("Provide your input in single digit (1-5): ");
				
			while(true){
				br = new BufferedReader(new InputStreamReader(System.in));
				input =  br.readLine();
				if(input.length()>1){
					System.out.println("Wrong input. Please enter single digit from 1 - 5");
				}
				else if(Character.digit(input.charAt(0),10) < 0){
					System.out.println("Wrong input. Please enter digit from 1 - 5");
				}
				else if(Integer.parseInt(input)>5 || Integer.parseInt(input)<0){
					System.out.println("Wrong input. Please enter digit from 1 - 5");
					
				}
				else
					break;
			}
			int in = Integer.parseInt(input);
			switch(in){
			
			case 1:
				new AccSummary();
				break;
			case 2:
				new MakeFund();
				break;
			case 3:
				new ViewPassbook();
				break;
			case 4:
				new New_Password(Login.User_Id,DbConnection.getConnection() );
				break;
			case 5:
				lt.interrupt();
				flag = 1;
				break;
			
			}
			if(flag == 1)
				break;
		}
		
	}
}
