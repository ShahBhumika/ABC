package pack1;

public class MakeFund
{
	public MakeFund() throws Exception 
	{
		// TODO Auto-generated constructor stub
		Fund_Transfer.transfer(FetchData.Account, DbConnection.getConnection());
	}

}
