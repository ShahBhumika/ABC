package pack1;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class PassSpec {
	static String pass;
	static String password;
	static String Rpassword;
	public int Spec() throws Exception{
		EncryptDecrypt EncDec = new EncryptDecrypt();;
		String psw;
		BufferedReader sc = new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Password Specifications: ");
		System.out.println("Your password should contain atleast one uppercase character");
		System.out.println("Your password should contain atleast one digit");
		System.out.println("Your password should contain atleast one lowercase character");
		System.out.println("Your password should contain atleast one special symbol");
		System.out.println("Your password length should be between 6 to 20 characters");
		System.out.println("ENTER PASSWORD");
		password=sc.readLine();
		password=Space.blankSpaces(password);
		if(password==null)
			return 0;
		PasswordValidator pswvld = new PasswordValidator();
		boolean correct = pswvld.validate(password);
		if(correct){
			
			psw = EncDec.encrypt(password);
			System.out.println("PLEASE RETYPE PASSWORD");
			Rpassword=sc.readLine();
			if(password.equals(Rpassword))
			{
				pass = psw;
				return 1;
			}
			else
			{
				System.out.println("Wrong password. Kindly type correct password");
			}
		}
		else{
			System.out.println("Your password does not follow specifications.");
		}
		return 0;
	}
}
