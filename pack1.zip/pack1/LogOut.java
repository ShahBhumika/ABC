package pack1;

import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.Statement;

public class LogOut {
	public LogOut() throws Exception{
		
		//Login.lt.interrupt();
		//Login log = new Login();
		PrintWriter writer = new PrintWriter(AbruptCheck.filename, "UTF-8");
		writer.println(1);
		writer.close();
		Connection con = DbConnection.getConnection();
		
		Statement st;
		
		st = con.createStatement();
		
		String sqlQuery = "update account set is_logged_in = 0 where User_ID='" + FetchUserId.User_Id + "'";
		st.executeQuery(sqlQuery);
		/*try {
			Features.br.close();
		} catch (Exception e) {
			// TODO: handle exception
		}*/
		System.out.println("You have logged out succecssfully.");
		System.exit(0);
		//Welcome.test();
	}
}