package pack1;

import java.io.File;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class WriteExcelDay 
{
	public WriteExcelDay(String email,String username,ArrayList<AccountTransaction> at)
	{
		AccountTransaction obje=(AccountTransaction)at.get(0);
		//System.out.println(obje.firstName);
		//System.out.println(at.size());
		int id=obje.accNo;
		String firstName=obje.firstName;
		String State=obje.State;
		String contact=obje.phNo;
		
		//Blank workbook
		XSSFWorkbook workbook = new XSSFWorkbook(); 
		
		//Create a blank sheet
		XSSFSheet sheet = workbook.createSheet("Employee Data");
		 
		//This data needs to be written (Object[])
		
		Map <Integer,Object[]> data= new TreeMap<Integer,Object[]>();
		data.put(1, at.toArray());
		data.put(2, new Object[] { "NAME", firstName});
		data.put(3, new Object[] { "State", State});
		data.put(4, new Object[] {"Account Number",id});
		data.put(5, new Object[] {"Contact",contact});
		data.put(6, new Object[] {"Transaction Summary"});
		int max=data.size();
		int count= max;
		//System.out.println(max);
		for(int i=0;i<at.size();i++)
		{
			//System.out.println(i);
			AccountTransaction o=(AccountTransaction)at.get(i);
			
			String trans=o.transactionType;
			String transDate=o.transactionDate;
		//System.out.println(transDate);
			//System.out.println(trans);
			String amt=o.amount;
			//System.out.println(amt);
			data.put(count+1, new Object[] {"Transaction Type",transDate,trans,amt,});
			//data.put("count+1",new Object[]{"",trans,amt});
	count++;
			
		}
		
		
		
		//data.put("4", new Object[] {3, "abhirami", "Adwards"});
	//	data.put("5", new Object[] {4, "Bhumika", "Schultz"});
		 
		//Iterate over data and write to sheet
		Set<Integer> keyset = data.keySet();
		int rownum = 0;
		for (Integer key : keyset)
		{
		    Row row = sheet.createRow(rownum++);
		    Object [] objArr = data.get(key);
		    int cellnum = 0;
		    for (Object obj : objArr)
		    {
		       Cell cell = row.createCell(cellnum++);
		       if(obj instanceof String)
		            cell.setCellValue((String)obj);
		        else if(obj instanceof Integer)
		            cell.setCellValue((Integer)obj);
		    }
		}
		try 
		{
			//Write the workbook in file system
			String url = "C:\\Bhumika.xlsx";
		    FileOutputStream out = new FileOutputStream(new File(url));
		    workbook.write(out);
		    out.close();
		    Csv_Sendingg obj = new Csv_Sendingg(email,"Account Passbook","Hi Check the Attached passbook",url);
		    //obj.SendMail();
		    System.out.println("file written onto the disk");
		     
		} 
		catch (Exception e) 
		{
		    e.printStackTrace();
		}
	}
}
