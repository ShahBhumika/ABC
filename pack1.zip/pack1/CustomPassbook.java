package pack1;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.sql.SQLException;

public class CustomPassbook {
	
	BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
	public CustomPassbook() throws SQLException, Exception{
		System.out.println("enter the starting date(eg:15-JAN-2016)");
		String startDate=br.readLine();
		
		System.out.println("enter the ending date(eg:15-JAN-2016)");
		String endDate=br.readLine();
		
		FetchData2 obj=new FetchData2();
		obj.Data(startDate, endDate);
		
	
		
		//new WriteExcelDay(FetchData.Email,Login.User_Id,);
		new ViewPassbook();
	}
}
