package pack1;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class InsertNewUser
{
	private static  String contact ;
	private static  String email ;
	private static  String firstname ;
	private static  String lastname ;
	private static  String username ;
	private static  String dob ;
	private static  String address ;
	private static  String question ;
	private static  String answer ;
	private static  String password ;
	private static  String House_No;
	private static  String Plot_No;
	private static  String Street;
	private static  String City;
	private static  String State;
	private static  String Alternate_Contact;
	public static  Long AccountNo;
	



	InsertNewUser(String contact,String email,String firstname,String lastname,String username,String dob,String Alternate_Contact,String House_No,String Plot_No,String Street,String City,String State,String question,String answer,String password){
		this.contact =contact;
		this.email = email;
		this.firstname = firstname;
		this.lastname = lastname;
		this.username = username;
		this.dob = dob;
		this.address = address;
		this.question = question;
		this.answer = answer;
		this.password = password;
		this.Alternate_Contact =  Alternate_Contact;
		this.House_No = House_No;
		this.Plot_No = Plot_No;
		this.Street = Street;
		this.City = City;
		this.State = State;
		

		
	}
	
	public static void Insert() throws Exception{
		//String string = "January 2, 2010";
		SimpleDateFormat format = new SimpleDateFormat("dd-MM-yyyy");
        Date parsed = format.parse(dob);
        java.sql.Date sql = new java.sql.Date(parsed.getTime());
		DbConnection con = DbConnection.getInstance();
		Connection conn = con.getConnection();
		CallableStatement cs = conn.prepareCall("{call INSERT_User_Det(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)}");
		cs.setString(1,firstname);
		cs.setString(2,lastname);
		cs.setString(3,username);
		cs.setString(4,contact);
		cs.setString(5,Alternate_Contact);
		cs.setString(6,House_No);
		cs.setString(7,Plot_No);
		cs.setString(8,Street);
		cs.setString(9,City);
		cs.setString(10,State);
		cs.setString(11,email);
		cs.setDate(12,  sql);
		cs.setString(13,question);
		cs.setString(14,answer);
		cs.setString(15,password);
		cs.setInt(16,0);
		//cs.setLong(17,AccountNo);
		cs.execute();
	/*	if(!cs.execute()){
			System.out.println("Statement executed!!");
		}
	*/	
		CallableStatement cs1 = conn.prepareCall("{call Password_Check(?,?)}");
		//	System.out.println(ForgetClass.User_Id);
			cs1.setString(1,username);
			cs1.setString(2,password);
			cs1.execute();
	}
	
		
	
}
