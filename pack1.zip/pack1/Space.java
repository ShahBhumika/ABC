package pack1;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.Scanner;

public class Space
{
	public static boolean containsWhiteSpace(final String testCode){
       
    if(testCode != null){
        for(int i = 0; i < testCode.length(); i++){
            if(Character.isWhitespace(testCode.charAt(i))){
                return true;
            }
        }
       
    }return false;
    
}
       public static String blankSpaces(String psw)throws Exception
       {
              String input;
              int flag=1;
              int flag1=1;
             input=psw;
              
                     do
                     {
              
              BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
             
              
              boolean white=containsWhiteSpace(input);
              
              if(white)
              {
                  flag1=0;  
                     System.out.println("Password Contains Spaces...Was it Intentional");
                     do
                     {
                           flag=0;
                           System.out.println("Press Y to confirm else N to discard");
                     String ch=br.readLine();
                     if(ch.equals("y")||ch.equals("Y"))
                     {
                           
                           
                           return psw;
                           ////SAVE PASSWORD QUERY
                           
                           
                           
                     }
                     else if(ch.equals("n")||ch.equals("N"))
                     {
                           System.out.println("Password Discarded");
                           
                           
                           ////CALLL PASSWORD FUNCTION(ENTER PASSWORD QUERY)
                          return null;
                           
                     }
                     else
                     {
                           System.out.println("Invalid Entry...Try Again");
                           flag=1;
                     }
                     }while(flag==1);
              }
              
              else if(input.length()>20||input.length()==0)
              {
                     System.out.println("Please Enter Valid Password...Try Again");
                     System.out.println("Enter Password");
                     input=br.readLine();
              }
              else
              {
                    
                     flag1=0;
                    
              }
       }while(flag1==1);
                     return input;
       }
       
}
