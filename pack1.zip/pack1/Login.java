package pack1;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.PrintWriter;
import java.sql.*;
import java.util.*;

public class Login
{
	static Connection con;
	static String User_Id;
	
	static String filename;
	public static void logging() throws Exception
	{
		/**
		 * Calling the connection class and establishing it
		 */
		int flag = 0;
		/**
		 * USING CONNECTION STATEMENT FOR CONNECTION CLASS
		 */
		
		con = DbConnection.getConnection();
		
		Statement st;
		
		st = con.createStatement();

		Scanner scan = new Scanner(System.in);
			/**
			 * GETTING THE USERID AND VALIDATING THE USER
			 */
			System.out.println("Enter the User Name:");
			User_Id = scan.next();
			String user_check = "select user_name from user_details where user_name='"+ User_Id + "'";

			ResultSet rs1, rs2, otp_rs;
			
			rs1 = st.executeQuery(user_check);
			
			if(rs1.next())
			{
						new FetchUserId(User_Id);
						FetchData fd = new FetchData(FetchUserId.User_Id);
						fd.Data();
						new AbruptCheck(User_Id);
						flag=1;
						
					//	System.out.println("UserID is correct");
						//String isActiveCheck = "select * from Account where username='"+ User_Id + "' and isactive=1 and isloggedin=0";
						String isActiveCheck = "select * from Account where user_id='"+ FetchUserId.User_Id + "' and is_logged_in=0";						
						rs2 = st.executeQuery(isActiveCheck);
								
								if(rs2.next())
								{	
									System.out.println("UserName is correct");
									
									String otp_status = "select pass_status from Account where User_id='"+ FetchUserId.User_Id + "'";
									otp_rs = st.executeQuery(otp_status);
									otp_rs.next();
									
									int s_otp =  otp_rs.getInt("pass_status");
									System.out.println("Status: "+s_otp);
									
									switch (s_otp) 
									{
										case 1:
											new Regular_User(User_Id, con);
											break;
										case 2:
											new Account_Blocked_User(User_Id, con);
											break;
											
										case 3:
											new ChangePassword(User_Id, con);
											break;
							
										default:
											System.out.println("Put correct input");
											break;
									}
								}
								else
								{
									System.out.println("Someone has already logged into your account.");	
								}
			
			}
			else
			{
				System.out.println("Please enter valid username");
				logging();
			}
	}
}