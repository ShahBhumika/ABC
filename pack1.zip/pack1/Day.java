package pack1;
import java.text.SimpleDateFormat;
import java.util.*;
import javax.swing.text.DateFormatter;

public class Day
{
	public static boolean dayofweek() throws Exception
	{	
			Calendar calendar = Calendar.getInstance();
			int dayOfWeek = calendar.get(Calendar.DAY_OF_WEEK);
			System.out.println(dayOfWeek);
			if(dayOfWeek==1||dayOfWeek==7)
			{
				System.out.println("You cannot make a transaction on Saturday and Sunday");
				return false;
			}
			else
				return true;	
	}
	
	public static boolean time() throws Exception
	{
	Calendar cal = Calendar.getInstance();
    SimpleDateFormat sdf = new SimpleDateFormat("HH:mm:ss");
    System.out.println( sdf.format(cal.getTime()) );
    String time[]=sdf.format(cal.getTime()).toString().split(":");	
    
    System.out.println("time[0]"+time[0]);
    int t = Integer.parseInt(time[0]);
   
    if(t<9)
    {
    	
    	System.out.println("You can make transactions only from 9:00 AM to 6:00 PM");
    	return false;
    }
    if(t>17)
    {
    	
    	System.out.println("You can make transactions only from 9:00 AM to 6:00 PM");
    	return false;
    }
    else
    {
    	return true;
    }
	}		
}