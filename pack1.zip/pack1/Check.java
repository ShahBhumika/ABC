package pack1;

public class Check
{	
	public static boolean alphabet(String str)
	{
		if(str.length()>=20 || str.length()==0)
		{
			
			return false; 
		}
		if(str.matches(".*\\d+.*"))
		{
			return false;
		}
		return true;
	}
	public static boolean digit(String str)
	{
		if(str.length()>15 || str.length()==0)
		{
			
			return false; 
		}
		if (str.matches("[0-9]+"))
		{
			return true;
		}
		return false;
	}
}
