package pack1;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.SQLException;

public class ViewPassbook
{
	ViewPassbook() throws SQLException, Exception{
		System.out.println("Select 1 for Standard Passbook and 2 for Custom Passbook");
		System.out.println("If you want to go to previous Menu Press 3");
		String input;
		while(true){
			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			input =  br.readLine();
			if(input.length()>1){
				System.out.println("Wrong input. Please enter single digit from 1 - 3");
			}
			else if(Character.digit(input.charAt(0),10) < 0){
				System.out.println("Wrong input. Please enter digit from 1 - 3");
			}
			else if(Integer.parseInt(input)>3 || Integer.parseInt(input)<0){
				System.out.println("Wrong input. Please enter digit from 1 - 3");
				
			}
			else
				break;
		}
		int in = Integer.parseInt(input);
		switch(in){
		case 1:
			new StandardPassbook();
			break;
		case 2:
			new CustomPassbook();
			break;
		case 3:
			Features.showPage();
			break;
		}
		
	}
}