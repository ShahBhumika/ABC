package pack1;

public class LogThread extends Thread
{
	@Override
	public void run() 
	{
		// TODO Auto-generated method stub
		try 
		{
			Thread.sleep(600000);
			//Thread.sleep(2000);
			new LogOut();
		} 
		catch (Exception e) 
		{
			// TODO Auto-generated catch block
			//System.out.println("Please try logging in again");
			
			try 
			{
				new LogOut();
				
			} 
			catch (Exception e1) 
			{
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
	}
}