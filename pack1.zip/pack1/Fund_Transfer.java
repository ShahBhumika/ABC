package pack1;

import java.io.*;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Scanner;

public class Fund_Transfer
{
	public static void transfer(int account,Connection con) throws Exception
						{
							boolean week_day=Day.dayofweek();
							boolean currenttime=Day.time();
							if(week_day)
							{
								if(currenttime)
								{
									int flag=1;
									Statement st=con.createStatement();
									String sql1="select account_balance from account where account_number ='"+account+"'";
									ResultSet rs=st.executeQuery(sql1);
									Float user_amount=0.0f;
										if(rs.next()){
											 user_amount=rs.getFloat("account_balance");//depositer available balance
										}
							
										if(user_amount>100)
										{
										Scanner sc =new Scanner(System.in);
										do
											{
		
												System.out.println("Enter the account number to which you want to transfer Funds ");
												String account_num=sc.next();
												if(Integer.parseInt(account_num) == account)
												{
													System.out.println("You can not make transaction to your account.");
													
												} 
							
												else if(account_num.matches("[0-9]+"))
												{
												String sql2="Select * from account where account_number='"+account_num+"' and is_active=1";
												ResultSet rs1=st.executeQuery(sql2);
												     if(rs1.next())
												     {
												    	 flag=0;
												    	 System.out.println("Enter the amount you want to transfer to account number "+account_num);//printing the account no.
												    	 String amount=sc.next();
												    	 Float amount_user2=Float.parseFloat(amount);
												    	 Float amount2;
												    	 String sql5="Select account_balance from account where account_number='"+account_num+"'";
												    	 ResultSet rs4=st.executeQuery(sql5);rs4.next();
												    	 amount2=rs4.getFloat("account_balance");//receiver available balance
											    	     	if(amount.matches("[0-9]+"))
											    	     	{
											    	     		if(user_amount>=amount_user2)
											    	     		{
													    	     			System.out.println("Enter Remarks");
													    	     			BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
													    	     			String Remark=br.readLine();
													    	     			Remark=account_num+Remark;
													    	     			String Remark1="from account no."+account;
													    	     			RandomGenerator rg = new RandomGenerator();
													    					int Otp = rg.GenOtp();
													    	     			new SimpleMailDemo(FetchData.Email, "Fund Transfer", "Fund transfer request has been initiated! ", Otp);
													    	     			System.out.println("Enter the OTP:");
													    	     			int o = sc.nextInt();
														    	     			while(true)
														    	     			{
															    	     			if(Otp==o)
															    	     			{
									    	     				
																    	     			//SimpleMailDemo obj = new SimpleMailDemo(,"Temperory Password",);
																    	     			
																    	     			user_amount=user_amount-amount_user2;
																    	     			amount2=amount2+amount_user2;
																    	     			String sql3="update account set account_balance='"+user_amount+"' where account_number='"+account+"'";
																    	     			st.executeUpdate(sql3);
																    	     			String s = "select User_id from account where Account_Number = '" +account_num + "'";
																    	     			ResultSet ResT = st.executeQuery(s);
																    	     			int UID = 0;
																	    	     			if(ResT.next()){
																	    	     				UID = ResT.getInt("User_id");
																	    	     			}
																	    	     			String sql4="update account set account_balance='"+amount2+"' where account_number='"+account_num+"'";
																	    	     			st.executeUpdate(sql4);
																	    	     			
																	    	     			/**
																	    	     			 * Generate transaction ID
																	    	     			 * for depositor1]
																	    	     			 */
																	    	     			String sql6="insert into transactions(User_Id,Transaction_id,Account_Number, Transaction_Type, Amount, Remarks, Transaction_Date) values("+FetchUserId.User_Id+"User_Account_Sequence.nextval,'"+account+"','debit','"+amount_user2+"','"+Remark+"',sysdate)";
																	    	    
																	    	     			st.executeQuery(sql6);
																	    	     			String sql7="insert into transactions(User_Id,Transaction_id,Account_Number, Transaction_Type, Amount, Remarks, Transaction_Date) values("+UID+"User_Account_Sequence.nextval,'"+account_num+"','credit','"+amount_user2+"','"+Remark1+"',sysdate)";
																	    	     			st.executeUpdate(sql6);
																	    	     			System.out.println("Your new balance is "+user_amount);
													    	     			
													    	     			
													    	     			
													    	     			/////SEND THE MAIL TO RECEIVER AND DEPOSITER
													    	     			
																	    	     			break;	
															    	     				}
															    	     			else{
															    	     				System.out.println("You entered wrong otp!");
															    	     			}
											    	     		/*else
											    	     		{
											    	     			System.out.println("You dont have enough balance to make this transaction");
											    	     			System.out.println("Your balance is "+user_amount);
											    	     		}*/
														    	     			}
									    	     			
											    	     		}
											    	     		else{
											    	     			System.out.println("Transaction amount is greater than available balance!");
											    	     		}
											    	     		
											    	     	}
											    	     	else
											    	     	{
											    	     		System.out.println("Amount must contain only integer values");
											    	     	}
												     }
												     else
												     {
												    	 System.out.println("Account number does not exist or Account is inActive");
												     }
							
												}
												else
												{
													System.out.println("Account number Should contain only INTEGERS");
												}
								
								
											}while(flag==1);
									
										}
										else
										{
											System.out.println("Balance is less then 100 your account is disabled to  transfer");
										}
								}
							}
	}
}
