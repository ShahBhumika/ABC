package pack1;

public class AccSummary
{
	String username;
	AccSummary(){
		
		if(Login.User_Id == null)
		{
			username = ForgetClass.User_Id;
		}
		else{
			username = Login.User_Id;
		}
		System.out.println("Your Account No is: " + FetchData.Account );
		System.out.println("Your User Name is: " + username );
		System.out.println("Ammount in your account is: " + FetchData.Ammount_Bal);
	}
}
