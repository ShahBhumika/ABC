package pack1;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;
public class Account_Blocked_User 
{
	
	public Account_Blocked_User(String User_Id, Connection con) throws Exception 
	{
		Statement st;		
		st = con.createStatement();
			/**
				 * GETTING PASSWORD AN VALIDATING IT
				 */
		//Scanner s = new Scanner(System.in);
		BufferedReader s = new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter the Password");
		String psw = s.readLine();
		String User_Password = new EncryptDecrypt().encrypt(psw);
		String login_check = "select password from user_details where User_Name='"+ User_Id + "'";
		ResultSet rs;
		rs = st.executeQuery(login_check);
		int count;
		while (rs.next()) 
		{
			String name1 = rs.getString("password");
			for (count = 0; count < 2; count++) 
			{  
				//ALLOWS TO ENTER PASSWORD FOR 2 TIMES
				if (name1.equals(User_Password)) 
				{
								/**
								 * SUCCESS LOGIN LOOP
								 */
					//System.out.println("Success");
					String update_isloggedin = "Update Account set is_logged_in = 1, is_active = 1, pass_status = 1 where user_id='"+ FetchUserId.User_Id + "'";
					st.executeQuery(update_isloggedin);
					
					Features F = new Features();
					F.showPage();
					break;
					
					
				}
				else 
				{
							/**
							 * RETRYING PASSWORD BLOCK
							 */
					System.out.println("Enter the Password Again(Tries left=)"+ (2 - count));
					psw = s.readLine();
					User_Password = new EncryptDecrypt().encrypt(psw);
				}
			}
					
			if (count == 2) 
			{
						/**
						 * SENDING MAIL AND BLOCKING THE ACCOUNT
						 */
				if (name1.equals(User_Password)) 
				{
								/**
								 * SUCCESS LOGIN LOOP
								 */

					System.out.println("Login Success!");
					String update_isloggedin = "Update Account set is_logged_in = 1 ,is_active = 1 where User_Id='"+ FetchUserId.User_Id + "'";
					st.executeQuery(update_isloggedin);
					new Features();
					Features.showPage();
					break;
				}
				else
				{
					SimpleMailDemo obj = new SimpleMailDemo(FetchData.Email,"Account Blocked","Hi! you have entered wrong password three times so your account has been blocked temporarily. Please contact the administrator (shahbhumika.93@gmail.com)");
					String update_inactive = "Update Account set is_active= 0, pass_status=2 where User_Id='"+ FetchUserId.User_Id + "'";
					st.executeQuery(update_inactive);
					System.out.println("Your account has been blocked. Try logging in with correct password");
					Login.logging();
				}
				
			}
		}
	}	
}