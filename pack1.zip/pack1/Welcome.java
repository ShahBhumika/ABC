package pack1;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.Scanner;

public class Welcome
{
	static void test()throws Exception
	{
		//Scanner sc=new Scanner(System.in);
		System.out.println("WELCOME TO CITI BANK");
		System.out.println("SELECT 1-NEW USERS");
		System.out.println("SELECT 2-EXISTING USERS");
		System.out.println("SELECT 3-FORGOT PASSWORD");
		//int ch=sc.nextInt();
		String input;
		while(true){
			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			input =  br.readLine();
			if(input.length()>1 || input.length()==0){
				System.out.println("Wrong input. Please enter single digit from 1 - 3");
			}
			else if(Character.digit(input.charAt(0),10) < 0){
				System.out.println("Wrong input. Please enter digit from 1 - 3");
			}
			else if(Integer.parseInt(input)>3 || Integer.parseInt(input)<0){
				System.out.println("Wrong input. Please enter digit from 1 - 3");
				
			}
			else
				break;
		}
		int ch = Integer.parseInt(input);
		switch(ch)
		{
		case 1:
			NewUser.information();
			break;
			
		case 2:
			Login.logging();
			break;
			
		case 3:
			ForgetClass.Forgets();
			break;
			
		default:
			System.out.println("Enter correct input"); 
			break;
		}
	}
	public static void main(String[] args)throws Exception
	{
		test();
	}
}
