package pack1;

import java.io.BufferedReader;
import java.io.InputStreamReader;
//import java.util.Date;
import java.sql.Date;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Locale;
import java.util.Scanner;

public class NewUser
{	static String username;
	static boolean test(String email)
	{
		//String EMAIL_REGEX = "^[\\w\\.+]*[\\w]\\@([\\w]+\\.)+[\\w]+[\\w]$";
		String EMAIL_REGEX = "^[A-Za-z][A-Za-z0-9\\.]*[A-Za-z0-9]\\@([A-Za-z]+\\.)+[A-Za-z]+[A-Za-z]$";

			      String email1 =email;
			      Boolean b = email1.matches(EMAIL_REGEX);
			return b;    
			      
	}
	public static void information()throws Exception
	{
		int flag = 1;
		System.out.println("OPEN YOUR ACCOUNT");
		//Message msg = Message.getInstance();
		EncryptDecrypt EncDec = new EncryptDecrypt();
		BufferedReader sc = new BufferedReader(new InputStreamReader(System.in));
		//String choice=null;
		
			while(true){
				System.out.println("ENTER USER NAME");
				username=sc.readLine();
				CheckUser User = new CheckUser();
				int  Existing = User.check(username);
				if(Existing != 0){
					System.out.println("Kindly choose another username.");
				}
				else{
					break;
				}
			}
			System.out.println("ENTER FIRST  NAME");
			String firstname=sc.readLine();
			while(true)
			{
				if(Check.alphabet(firstname))
				{
					break;	
				}
				else				
				{
					System.out.println("Invalid FirstName..Try Again");
					System.out.println("Enter Again FirstName");
					firstname=sc.readLine();
				}
			}
			System.out.println("ENTER LAST NAME");
			String lastname=sc.readLine();
			while(true)
			{
				if(Check.alphabet(lastname))
				{
					break;	
				}
				else				
				{
					System.out.println("Invalid Lastname..Try Again");
					System.out.println("Enter Again Lastname");
					lastname=sc.readLine();
				}
			}
//			System.out.println("ENTER DATE OF BIRTH(DD-MM-YYYY)");
//			String dob=sc.readLine();
			String dob=DateValidator.dateVal();
			/*System.out.println(dob);
			Date date = java.sql.Date.valueOf("14-06-2016");*/
			//System.out.println(java.sql.Date.valueOf());
			//System.out.println(date);
			System.out.println("ENTER EMAIL ID");
			String email;
			while(true)
			{
				email=sc.readLine();
				if(email.length()==0)
				{
					System.out.println("Enter a Email id");
					continue;
				}
				else
				{
				Boolean validEmail=test(email);
				if(validEmail)
				{
					break;
				}else
				{
					System.out.println("Invalid Email id");
					//msg.printMsg("Invalid Email id");
					System.out.println("PLEASE ENTER CORRECT EMAIL");
				}
				//end of length()
				}
			}
			System.out.println("ENTER CONTACT");
			String contact=sc.readLine();
			while(true)
			{
				if(Check.digit(contact))
				{
					break;	
				}
				else				
				{
					System.out.println("Invalid contact..Try Again");
					System.out.println("Enter Again contact");
					contact=sc.readLine();
				}
			}
			System.out.println("ENTER Alternate_contact");
			String Alternate_contact=sc.readLine();
			while(true)
			{
				if(Check.digit(Alternate_contact))
				{
					break;	
				}
				else				
				{
					System.out.println("Invalid Alternate Contact..Try Again");
					System.out.println("Enter Again Alternate Contact");
					Alternate_contact=sc.readLine();
				}
			}
			System.out.println("ENTER HOUSE NUMBER");
			String house_no=sc.readLine();
			while(true)
			{
				if(house_no.length()>=20 || house_no.length()==0)
				{
					System.out.println("Invalid House No..Try Again");
					System.out.println("Enter Again House No.");
					house_no=sc.readLine();
				}
				else				
				{
					break;
				}
			}
			System.out.println("ENTER PLOT NUMBER");
			String plot_no=sc.readLine();
			while(true)
			{
				if(plot_no.length()>=20 || plot_no.length()==0)
				{
					System.out.println("Invalid plot no..Try Again");
					System.out.println("Enter Again Plot No.");
					plot_no=sc.readLine();
				}
				else				
				{
					break;
				}
			}
			System.out.println("ENTER STREET");
			String street=sc.readLine();
			while(true)
			{
				if(street.length()>=20 || street.length()==0)
				{
					System.out.println("Invalid street...Try Again");
					System.out.println("Enter Again street");
					street=sc.readLine();
				}
				else				
				{
					break;
				}
			}
			System.out.println("ENTER CITY");
			String city=sc.readLine();
			while(true)
			{
				if(city.length()>=20 || city.length()==0)
				{
					System.out.println("Invalid City..Try Again");
					System.out.println("Enter Again City");
					city=sc.readLine();
				}
				else				
				{
					break;
				}
			}
			System.out.println("ENTER STATE");
			String state=sc.readLine();
			while(true)
			{
				if(state.length()>=20 || state.length()==0)
				{
					System.out.println("Invalid State..Try Again");
					System.out.println("Enter Again State");
					state=sc.readLine();
				}
				else				
				{
					break;
				}
			}

			String value=Security.question();
			String value1[]= value.split("/");
			String question=value1[0];
			String answer=value1[1];
			String psw = "";
			while(true){
				flag = new PassSpec().Spec();
				if(flag == 1)
					break;
				
			}

			
			flag = 0;
			
			
			InsertNewUser in = new InsertNewUser(contact,email,firstname,lastname,username,dob,Alternate_contact,house_no,plot_no,street,city,state,answer,question,PassSpec.pass);
			while(flag == 0)
			{
				System.out.println("Sending an OTP to your email....");
				System.out.println(psw);
				RandomGenerator rg = new RandomGenerator();
				Long accN = rg.GenAccNum();
				in.AccountNo = accN;
				int Otp = rg.GenOtp();
				SimpleMailDemo Mail = new SimpleMailDemo(email, "Account Verification", "Hi '"+ firstname  +"' Your account has been created successfully. ", Otp);
				System.out.println("Provide the OTP sent to your mail : ");
				int Input = Integer.parseInt(sc.readLine());
				if(Input == Otp)
				{
					in.Insert();
					new FetchUserId(username);
					InsertAccount ia = new InsertAccount(FetchUserId.User_Id,accN,1,0,0,0,1);
					
					ia.insert();
					System.out.println("Your registration has been done successfully!" + " Your Account No is: "+ accN);
					flag++;
					
				}
				else
				{
					System.out.println("you provided wrong OTP");
					
				}
			}
		Login log = new Login();
		log.logging();
	}
}
