package pack1;

import java.util.Random;
public class RandomGenerator
{
	static Long accNum;
	static int OTP;
	
	public  Long GenAccNum()
	{
		Random Ran = new Random();
		accNum=(long) (Ran.nextInt(999)*Ran.nextInt(999)+100000);
		return accNum;
	}
	public  int GenOtp()
	{
		Random Ran = new Random();
		OTP=Ran.nextInt(9999)+1000;
		return OTP;
	}
} 
