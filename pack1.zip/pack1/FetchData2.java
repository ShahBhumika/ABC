package pack1;

import java.sql.*;
import java.util.ArrayList;
public class FetchData2
{
		static String fname;
		static String lname;
		static String address;
		static String Phone_num;
		//static String Tran_Date;
		//static String Tran_Type;
		//static int Account;
		
		static String User_Email;
		static int Account_Number;
		static int Ammount_Bal;
				
		public void Data(String startDate,String endDate) throws Exception{
			DbConnection con = DbConnection.getInstance();
			Connection conn = con.getConnection();
			/*System.out.println(Login.User_Id);
			CallableStatement cs = conn.prepareCall("{call Fetch_Data(?,?,?,?,?,?,?,?)}");
			cs.setString(1,Login.User_Id);
			cs.registerOutParameter(2, java.sql.Types.VARCHAR);
			cs.registerOutParameter(3, java.sql.Types.VARCHAR);
			cs.registerOutParameter(4, java.sql.Types.VARCHAR);
			cs.registerOutParameter(5, java.sql.Types.VARCHAR);
			cs.registerOutParameter(6, java.sql.Types.VARCHAR);
			cs.registerOutParameter(7, java.sql.Types.INTEGER);
			cs.registerOutParameter(8, java.sql.Types.INTEGER);
			cs.execute();
			fname = cs.getString(2);
			lname = cs.getString(3);
			address = cs.getString(4);
			Phone_num = cs.getString(5);
			User_Email = cs.getString(6);
			Account_Number=cs.getInt(7);
			Ammount_Bal=cs.getInt(8);*/
			//System.out.println(fname+lname+address);
			
			ArrayList< AccountTransaction> at= new ArrayList<AccountTransaction>();
			String query= "select Account.account_number,Transactions.Transaction_Date,Transactions.transaction_type,Transactions.amount,to_char(Transactions.transaction_date,'DD-MON-YYYY HH:MI:SS AM') " +
					"  from Account,Transactions where Account.user_id='"+FetchUserId.User_Id+"' and Account.account_number=Transactions.account_number and Transactions.Transaction_Date>'"+startDate+"'and Transactions.Transaction_Date<='"+endDate+"'" ;
			Statement stmt= conn.createStatement();
			//System.out.println("User Id" +Login.User_Id);
			ResultSet rs=stmt.executeQuery(query);
			//System.out.println(query);
			while(rs.next())
			{
				int accNo=rs.getInt("account_number");
				System.out.println(accNo);
				String type=rs.getString("transaction_type");
				String amount= rs.getString("amount");
				String transDate=rs.getString("transaction_date");
				at.add(new AccountTransaction(FetchData.fname,FetchData.lname,FetchData.HouseNo,FetchData.PlotNo,FetchData.Street,FetchData.City,FetchData.State,FetchData.Phone_num,accNo,type, amount,FetchData.Ammount_Bal,transDate));
			}
			
			/*2
			 * */
			if(at.size() != 0){
				WriteExcelDay obj =new WriteExcelDay(FetchData.Email, Login.User_Id,at);
				System.out.println("Hi, your passbook has been sent to your email. Kindly check.");
			}
			else{
				System.out.println("You have not done any transactions in specified date range.");
			}
		
			
		}
		
}
