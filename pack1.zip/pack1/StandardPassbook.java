package pack1;

import java.sql.Connection;

public class StandardPassbook 
{
	public StandardPassbook() throws Exception 
	{
		// TODO Auto-generated constructor stub
		Passbook_Console pc = new Passbook_Console();
		pc.passbook(FetchData.Account, DbConnection.getConnection());
		
	}
}
