package pack1;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

public class FetchUserId {
	static int User_Id;
	public FetchUserId(String username) throws Exception{
		Connection con = DbConnection.getConnection();
		Statement st ;
		st = con.createStatement();
		String sql = "select user_id from user_details where user_name =  '"+ username + "'";
		ResultSet rs = st.executeQuery(sql);
		if(rs.next()){
			User_Id = rs.getInt("user_id");
		}
	}
}
