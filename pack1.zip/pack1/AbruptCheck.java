package pack1;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.sql.Statement;

public class AbruptCheck {
	static String filename;
	Statement st;
	public AbruptCheck(String Username) throws SQLException, Exception{
		st = DbConnection.getConnection().createStatement();
		filename = "C:/Abrupt" + Username +".txt";
		File f = new File(filename);
		if(f.exists() && !f.isDirectory()) { 
		    // do something
			BufferedReader br = new BufferedReader(new FileReader(filename));
			int s = Integer.parseInt(br.readLine());
			if(s==0){
				String Query = "update Account set is_logged_in=0 where user_id = '"+ FetchUserId.User_Id + "'";
				st.executeUpdate(Query);
			}
			
		}
		else{
			PrintWriter writer = new PrintWriter(filename, "UTF-8");
			writer.println(0);
			writer.close();
		}
	}
}
