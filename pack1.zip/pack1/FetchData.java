package pack1;

import java.sql.CallableStatement;
import java.sql.Connection;

public class FetchData
{
		static String fname;
		static String lname;
		static String HouseNo;
		static String PlotNo;
		static String Street;
		static String City;
		static String State;
		static String Phone_num;
		static String Tran_Date;
		static String Tran_Type;
		static int Account;
		static int Ammount_Bal;
		static String Email;
		static int uid;
		public FetchData(int uid){
			this.uid = uid;
		}
		public void Data() throws Exception
		{
			DbConnection con = DbConnection.getInstance();
			Connection conn = con.getConnection();
			CallableStatement cs = conn.prepareCall("{call Fetch_Data(?,?,?,?,?,?,?,?,?,?,?,?)}");
			//cs.setString(1, Login.User_Id);
			cs.registerOutParameter(1, java.sql.Types.VARCHAR);
			cs.registerOutParameter(2, java.sql.Types.VARCHAR);
			cs.registerOutParameter(3, java.sql.Types.VARCHAR);
			cs.registerOutParameter(4, java.sql.Types.VARCHAR);
			cs.registerOutParameter(5, java.sql.Types.VARCHAR);
			cs.registerOutParameter(6, java.sql.Types.VARCHAR);
			cs.registerOutParameter(7, java.sql.Types.VARCHAR);
			cs.registerOutParameter(8, java.sql.Types.VARCHAR);
			cs.registerOutParameter(9, java.sql.Types.VARCHAR);
			cs.registerOutParameter(10, java.sql.Types.INTEGER);
			cs.registerOutParameter(11, java.sql.Types.INTEGER);
			cs.setInt(12, uid);
			cs.execute();
			fname = cs.getString(1);
			lname = cs.getString(2);
			HouseNo = cs.getString(3);
			PlotNo = cs.getString(4);
			Street = cs.getString(5);
			City = cs.getString(6);
			State = cs.getString(7);
			Phone_num = cs.getString(8);
			Email = cs.getString(9);
			Account = cs.getInt(10);
			Ammount_Bal = cs.getInt(11);
			
			
			
		}
}