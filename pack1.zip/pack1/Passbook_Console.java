package pack1;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.Statement;

public class Passbook_Console
{
	public static void passbook(int accountno,Connection con)throws Exception
	{
		Statement stmt=con.createStatement();
		ResultSet rs,rs1;
		System.out.println();
		System.out.println("          							    YOUR ACCOUNT NO. is "+accountno);
		System.out.println();
		System.out.println();
		rs=stmt.executeQuery("select *from transactions where account_number ='"+accountno+"'");
		ResultSetMetaData rsmd=rs.getMetaData();
		System.out.println(rsmd.getColumnName(1)+"				"+rsmd.getColumnName(3)+"				"+rsmd.getColumnName(4)+"				"+rsmd.getColumnName(5)+"				"+rsmd.getColumnName(6));
		String sql="select *from transactions where account_number='"+accountno+"' and  transaction_date  > sysdate-31";
		rs1=stmt.executeQuery(sql);
		
		while(rs1.next())
		{
			System.out.println(""+rs1.getInt(1)+"						"+rs1.getString(3)+"					"+rs1.getInt(4)+"				"+rs1.getString(5)+"				"+rs1.getString(6));
		}
	}
}