package pack1;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class PasswordCheck {
	public int CheckPsw(String User_Id,String Psw, Connection con) throws Exception
	{
		Statement st;
		st = con.createStatement();
		String login_check = "select password from Password_Record where username='"+ User_Id + "'";
		ResultSet rs;
		rs = st.executeQuery(login_check);
		int count;
		while (rs.next()) 
		{
			if(rs.getString("password").equals(new EncryptDecrypt().encrypt(Psw)))
			{
				//System.out.println("workeeedd");
				return -1;
			}
			else{
				//System.out.println("workeeeddfasdfasd");
				//return 1;
			}
		
		}
		//System.out.println(ForgetClass.User_Id);
		CallableStatement cs = con.prepareCall("{call Password_Check(?,?)}");
	//	System.out.println(ForgetClass.User_Id);
		cs.setString(1,User_Id);
		cs.setString(2,new EncryptDecrypt().encrypt(Psw));
		cs.execute();
		return 1;
	}
}