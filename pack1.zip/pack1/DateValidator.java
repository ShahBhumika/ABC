package pack1;

import java.util.Calendar;
import java.io.*;
public class DateValidator
{
	
	
	public static String dateVal() throws Exception
	{
		String date;
		int flag=0;
		do
		{
			
		System.out.println("Please enter date(dd-mm-yyyy)");
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		date=br.readLine();
		
		

int year = Calendar.getInstance().get(Calendar.YEAR);
		
		try
		{
			flag=0;
		String time[]=date.split("-");	
	    int t = Integer.parseInt(time[0]);
	    int h=Integer.parseInt(time[1]);
	    int k=Integer.parseInt(time[2]);
	    if(k>=(year-75)&&k<=year)
	    {
	    if(h==1||h==3||h==5||h==7||h==8||h==10||h==12)
	    {
	    if(t>=1&&t<=31)
	    {
	    	
	    }
	    else
	    {
	    	flag=1;
	    	System.out.println("Invalid Date");
	    }
	    }
	    else if(h==4||h==6||h==9||h==11)
	    {
	    	 if(t>=1&&t<=30)
			    {
			    	
			    }
			    else
			    {
			    	flag=1;
			    	System.out.println("Invalid Date");
			    }
	    
	    }
	    else if(h==2)
	    {
	    	if(t>=1&&t<=29)
		    {
		    	
		    }
		    else
		    {
		    	flag=1;
		    	System.out.println("Invalid Date");
		    }
	    }
	    else
	    {
	    	flag=1;
	    	System.out.println("Invalid Date");
	    }
	    
}

else
{
	flag=1;
	System.out.println("Invalid Year");
}
		
		}
		catch(Exception e)
		{
			flag=1;
		System.out.println("Invalid Date");
		}
		}
		while(flag==1);	
		return date;
	}
}
