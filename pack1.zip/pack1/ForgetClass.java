package pack1;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Scanner;

public class ForgetClass {

	static Connection con;
	static String User_Id;
	public static void Forgets() throws Exception {
		int count,flag=0;
		String answer;
		/**
		 * USING CONNECTION_CLASS FOR GETTING CONNECTION
		 */
		con = DbConnection.getConnection();
		Statement st = con.createStatement();
		//Scanner scan = new Scanner(System.in);
		BufferedReader s = new BufferedReader(new InputStreamReader(System.in));
		/**
		 * GETTING THE USERID
		 */
		
         do
         {
		System.out.println("Enter the User Name: ");
		 User_Id = s.readLine();
		
		/**
		 * CHECKING FOR THE VALID USERID
		 */
		String user_check1 = "select user_name from user_details where user_name='"+ User_Id + "'";
		ResultSet rs1, rs,rs3;
		rs = st.executeQuery(user_check1);
        
		if (rs.next()) {
			 new FetchUserId(User_Id);
				FetchData fdd = new FetchData(FetchUserId.User_Id);
			//FetchData fdd = new FetchData(User_Id);
			fdd.Data();
			String user_check2="select is_active from account where User_Id='"+ FetchUserId.User_Id + "'"+"and is_active=1";
	        rs3=st.executeQuery(user_check2);
	        if(rs3.next())
	        {
			/**
			 * GET THE SECURITY QUESTION AND CHECKING THE SECURITY ANSWER
			 */
			//System.out.println("A Valid User");
			String sec_quest = "select * from user_details where user_name='"+ User_Id + "'";
			rs1 = st.executeQuery(sec_quest);
			rs1.next();
			String DbAnswer = rs1.getString("security_answer");
			System.out.println("" + rs1.getString("security_question"));
			answer = s.readLine();
			if (answer.equals(DbAnswer)) 
			{
				/**
				 * GENERATES A RANDOM ALPHANUMERIC PASSWORD
				 */
				String randomNum = ForgotPassword.randomString();
				String RandomPsw = new EncryptDecrypt().encrypt(randomNum);
				System.out.println(randomNum);
				String newPassword = "update user_details set password='"+ RandomPsw + "'where user_name='" + User_Id + "'";
				st.executeUpdate(newPassword);
				//System.out.println(newPassword);
               flag=1;
				/**
				 * MAIL
				 */
              // System.out.println(FetchData.Email);
               SimpleMailDemo obj = new SimpleMailDemo(FetchData.Email,"Temperory Password",randomNum);
               String temp_otp = "update Account set pass_status=3 where user_id='" + FetchUserId.User_Id + "'";
               new ChangePassword(User_Id, con);
			}

			else 
			{
				/**
				 * ALLOWS THE USER TO ENTER SECURIY ANS FOR 2 TIMES
				 */
				System.out.println("Enter the Security Answer Again");
				answer =s.readLine();

				for (count = 0; count < 2; count++) {

					/**
					 * IF USER ENTERS THE CORRECT ANSWER IN FURTHER ATTEMPTS
					 */
					if (answer.equals(DbAnswer)) {
						String randomNum = ForgotPassword
								.randomString();
						String RandomPsw = new EncryptDecrypt().encrypt(randomNum);
						String newPassword = "update user_details set password='"
								+ RandomPsw
								+ "' where user_name='"
								+ User_Id
								+ "'";
						st.executeUpdate(newPassword);
					//	System.out.println(newPassword);
                       flag=1;
						System.out.println("Password generated. Kindly check your mail");
						/**
						 * Add the mail
						 * 
						 */
						SimpleMailDemo obj = new SimpleMailDemo(FetchData.Email,"New Password","Your New Password is: "+ RandomPsw);
						/*String sql = "update Account set pswd_status=1 where username='" + User_Id + "'";
						st.execute(sql);*/
						Welcome we = new Welcome();
						we.test();
						break;

					}// end of ifanswer
					else 
					{
						System.out.println("Enter the Security Again(Tries left=)"+ (2 - count));
						answer = s.readLine();
					}
				}// end of for loop

			}// endofelse

		}
	        else
	        {
	        	System.out.println("Your account is inactive");
	        }
	        
		}// endofif
		else {
			System.out.println("Invalid User");
		}
       }while(flag==0);//THIS HELPS TO ENTER THE USERID REPEATEDLY IF USER ENTER A WRONG USER_ID
	}// endofmain
}// endofclass
